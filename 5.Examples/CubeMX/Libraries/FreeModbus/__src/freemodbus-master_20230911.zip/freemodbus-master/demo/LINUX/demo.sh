./modpoll -b 38400 -d 8 -p even -a 10 -t 3 -r 1000 /dev/ttyS1
