# uC/LIB

Designed with Micrium’s renowned quality, scalability and reliability, the purpose of µC/LIB is to provide a clean, organized ANSI C implementation of the most common standard library functions, macros, and constants.

## For the complete documentation, visit https://doc.micrium.com/display/ucos/