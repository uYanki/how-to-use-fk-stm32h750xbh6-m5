# uC/CPU

Designed with Micriμm’s renowned quality, scalability and reliability, the purpose of μC/ CPU is to provide a clean, organized ANSI C implementation of each processor’s/ compiler’s hardware-dependent.

## For the complete documentation, visit https://doc.micrium.com/display/ucos/