#ifndef DL_TIME_LIB_H__
#define DL_TIME_LIB_H__

#include "dl_extern_lib.h"
#include <time.h>


#define CLOCK			0
#define TIME			1

#endif
