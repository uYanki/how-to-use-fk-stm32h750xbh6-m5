#include "dl_lib.h"
#include "dl_elf.h"

#if 0
extern uint8_t* Image$$DL_Export_Sym$$Base;
extern uint32_t Image$$DL_Export_Sym$$Length;
#define DL_EXPORT_SYMBOL(symbol)		\
const char __dl_##symbol##_name[]=#symbol;\
const __attribute__((section("DL_Export_Sym"))) DL_Symbol_Type __dl_struct_##symbol={\
	__dl_##symbol##_name,\
	(void*)&symbol,\
};
static inline void* dl_find_symbol(const char* symbol,DL_Symbol_Type* pImport,uint32_t sym_num){
	if(pImport!=NULL){
		for(size_t i=0;i<sym_num;i++){
			if(strcmp(pImport[i].name,symbol)==0){
				return pImport[i].addr;
			}
		}
	}
	return NULL;
}
#endif

extern DL_Err_Type dl_relocate(DL_Handler *pHandle, Elf32_Rel *rel, Elf32_Addr sym_val);

//����elf�ļ��������
//pHandle�����
//lib_ptr���ļ������׵�ַ
//����ֵ��DL_Err_Type ���������������Ĵ���
static DL_Err_Type dl_load_shared_object(DL_Handler* pHandle,void* lib_ptr){
	bool has_vstart=false;
	Elf_Addr vstart_addr=0, vend_addr=0;
	uint32_t dynsym_off;
	DL_Err_Type err=DL_NO_ERR;
	//������������׵�ַ�Լ����м������Ĵ�С
	for(size_t i = 0;i<elf_header(lib_ptr)->e_phnum;i++){
		if(elf_phdr(lib_ptr)[i].p_type!=PT_LOAD)
			continue;
		DL_LOG_D("LOAD segment: %d, 0x%p, 0x%08x\r\n", i, (void*)elf_phdr(lib_ptr)[i].p_vaddr, elf_phdr(lib_ptr)[i].p_memsz);
		if (elf_phdr(lib_ptr)[i].p_memsz < elf_phdr(lib_ptr)[i].p_filesz){
            DL_LOG_E("invalid elf: segment %d: p_memsz: %d, p_filesz: %d",\
				i, elf_phdr(lib_ptr)[i].p_memsz, elf_phdr(lib_ptr)[i].p_filesz);
			err=DL_FILE_INVALID;
            goto fail0;
        }
		if(has_vstart==false){
			vstart_addr = elf_phdr(lib_ptr)[i].p_vaddr;
            vend_addr = elf_phdr(lib_ptr)[i].p_vaddr + elf_phdr(lib_ptr)[i].p_memsz;
            has_vstart = true;
            if (vend_addr < vstart_addr){
                DL_LOG_E("invalid elf: segment %d: p_vaddr: %d, p_memsz: %d",
                           i, elf_phdr(lib_ptr)[i].p_vaddr, elf_phdr(lib_ptr)[i].p_memsz);
                err=DL_FILE_INVALID;
				goto fail0;
            }
		}
		else{
			if (elf_phdr(lib_ptr)[i].p_vaddr < vend_addr){
                DL_LOG_E("invalid elf: segment should be sorted and not overlapped");
                err=DL_FILE_INVALID;
				goto fail0;
            }
            if (elf_phdr(lib_ptr)[i].p_vaddr > vend_addr + 16){
                /* There should not be too much padding in the object files. */
                DL_LOG_E("warning: too much padding before segment %d", i);
            }

            vend_addr = elf_phdr(lib_ptr)[i].p_vaddr + elf_phdr(lib_ptr)[i].p_memsz;
            if (vend_addr < elf_phdr(lib_ptr)[i].p_vaddr){
                DL_LOG_E("invalid elf: "
                           "segment %d address overflow", i);
                err=DL_FILE_INVALID;
				goto fail0;
            }
		}
	}
	
	//���ݼ�������С�����ڴ�
	pHandle->mem_size=vend_addr-vstart_addr;
	pHandle->vstart_addr=vstart_addr;
	DL_LOG_D("module size: %d, vstart_addr: 0x%p", pHandle->mem_size, (void*)vstart_addr);
	if(pHandle->mem_size==0){
		DL_LOG_E("Module: size error\n");
		err=DL_MEMSIZE_ERR;
        goto fail0;
	}
	pHandle->mem_ptr=malloc(pHandle->mem_size);
	if(pHandle->mem_ptr==NULL){
		DL_LOG_E("Module: allocate space failed.");
		err=DL_MALLOC_FAIL;
        goto fail0;
	}
	memset(pHandle->mem_ptr,0,pHandle->mem_size);
	
	//�����ļ����ݵ���������
	for(size_t i=0;i<elf_header(lib_ptr)->e_phnum;i++){
		if(elf_phdr(lib_ptr)[i].p_type==PT_LOAD){
			memcpy((uint8_t*)pHandle->mem_ptr+elf_phdr(lib_ptr)[i].p_vaddr-vstart_addr,\
					(uint8_t*)lib_ptr+elf_phdr(lib_ptr)[i].p_offset,\
					elf_phdr(lib_ptr)[i].p_filesz);
		}
	}
	
	//�˴����ֹ��������ִ���ļ�
	if(elf_header(lib_ptr)->e_entry!=0){//�����ڳ�����ڵ�
		pHandle->entry_addr=(uint8_t*)pHandle->mem_ptr + elf_header(lib_ptr)->e_entry - vstart_addr;
	}
	else{
		pHandle->entry_addr=NULL;
	}
	
	//��ʼ�ض���
	//Ѱ�Ҵ����ض�����Ϣ�Ľ���
	for(size_t i=0;i<elf_header(lib_ptr)->e_shnum;i++){
		Elf_Sym *symtab;
        Elf_Rel *rel;
        char *strtab;
		size_t nr_reloc;
		#if (defined(__arm__) || defined(__i386__) || (__riscv_xlen == 32))
        if (!IS_REL(elf_shdr(lib_ptr)[i]))
            continue;
        #elif (defined(__aarch64__) || defined(__x86_64__) || (__riscv_xlen == 64))
        if (!IS_RELA(elf_shdr(lib_ptr)[i]))
            continue;
        #endif
		//��ȡ�ض������ı�ͷ
		rel = (Elf_Rel *)((uint8_t *)lib_ptr + elf_shdr(lib_ptr)[i].sh_offset);
		//��ȡ��̬���ű��ı�ͷ
		symtab = (Elf_Sym *)((uint8_t *)lib_ptr + elf_shdr(lib_ptr)[elf_shdr(lib_ptr)[i].sh_link].sh_offset);
		//��ȡ��̬���Ŵ������ַ������ı�ͷ
        strtab = (char*)((uint8_t *)lib_ptr +elf_shdr(lib_ptr)[elf_shdr(lib_ptr)[elf_shdr(lib_ptr)[i].sh_link].sh_link].sh_offset);
        nr_reloc = (size_t)(elf_shdr(lib_ptr)[i].sh_size / sizeof(Elf_Rel));
		for(size_t j=0;j<nr_reloc;j++){
			#if (defined(__arm__) || defined(__i386__) || (__riscv_xlen == 32))
            Elf_Sym *sym = &symtab[ELF32_R_SYM(rel[j].r_info)];
            #elif (defined(__aarch64__) || defined(__x86_64__) || (__riscv_xlen == 64))
            Elf_Sym *sym = &symtab[ELF64_R_SYM(rel[j].r_info)];
            #endif
			DL_LOG_D("relocate symbol %s shndx %d", strtab + sym->st_name, sym->st_shndx);
			if ((sym->st_shndx != SHT_NULL) ||(ELF_ST_BIND(sym->st_info) == STB_LOCAL)){//������ſ��Խ���
                Elf_Addr addr;

                addr = (Elf_Addr)((uint8_t*)pHandle->mem_ptr + sym->st_value - vstart_addr);
                err=dl_relocate(pHandle, &rel[j], addr);
				if(err!=DL_NO_ERR){
					goto fail1;
				}
            }
            else{//���ⲿ�������
				 //���ڱ�����ԭ���ݲ�֧��
			#if 0
                Elf_Addr addr;

                DL_LOG_D("relocate symbol: %s\r\n", strtab + sym->st_name);
                /* need to resolve symbol in kernel symbol table */
                addr = (Elf_Addr)dl_find_symbol((const char *)(strtab + sym->st_name),\
												(DL_Symbol_Type*)(Image$$DL_Export_Sym$$Base),\
												Image$$DL_Export_Sym$$Length);
                if (addr == 0){
                    DL_LOG_E("Module: can't find %s in kernel symbol table", strtab + sym->st_name);
                    err=DL_UNDEF_SYM_ERR;
					goto fail1;
                }
                else{
                    err=dl_relocate(pHandle, &rel[j], addr);
					if(err!=DL_NO_ERR){
						goto fail1;
					}
                }
			#else
				DL_LOG_E("Module: can't find %s in kernel symbol table", strtab + sym->st_name);
				err=DL_UNDEF_SYM_ERR;
				goto fail1;
			#endif
            }
		}
	}
	
	//�������ű�
	for(dynsym_off=0;dynsym_off<elf_header(lib_ptr)->e_shnum;dynsym_off++){
		uint8_t *shstrab;
		shstrab = (uint8_t *)lib_ptr +
                  elf_shdr(lib_ptr)[elf_header(lib_ptr)->e_shstrndx].sh_offset;
		if(strcmp((const char *)(shstrab + elf_shdr(lib_ptr)[dynsym_off].sh_name), ELF_DYNSYM)==0)
			break;
	}
	
	if(dynsym_off!=elf_header(lib_ptr)->e_shnum){
		int count = 0;
        Elf_Sym  *symtab = NULL;
        uint8_t *strtab = NULL;

        symtab = (Elf_Sym *)((uint8_t *)lib_ptr + elf_shdr(lib_ptr)[dynsym_off].sh_offset);
        strtab = (uint8_t *)lib_ptr + elf_shdr(lib_ptr)[elf_shdr(lib_ptr)[dynsym_off].sh_link].sh_offset;

		//���Ҷ�̬�η��Ÿ���������Ԥ�����ڴ�
        for (size_t i = 0; i < elf_shdr(lib_ptr)[dynsym_off].sh_size / sizeof(Elf_Sym); i++){
            if ((ELF_ST_BIND(symtab[i].st_info) == STB_GLOBAL) &&
                (ELF_ST_TYPE(symtab[i].st_info) == STT_FUNC))
                count ++;
        }
		
		pHandle->nsym = count;
		pHandle->symtab = (DL_Symbol_Type *)malloc(count*sizeof(DL_Symbol_Type));
		if(pHandle->nsym != 0){
			if(pHandle->symtab == NULL){
				DL_LOG_E("Module: allocate space failed.");
				err=DL_MALLOC_FAIL;
				goto fail2;
			}
			memset(pHandle->symtab,0,count*sizeof(DL_Symbol_Type));
			
			//����̬���Ŷε����ݸ��Ƶ��ڴ���
			for (size_t i = 0, j = 0; i < elf_shdr(lib_ptr)[dynsym_off].sh_size / sizeof(Elf_Sym); i++){
				size_t length;

				if ((ELF_ST_BIND(symtab[i].st_info) != STB_GLOBAL) ||
					(ELF_ST_TYPE(symtab[i].st_info) != STT_FUNC))
					continue;

				length = strlen((const char *)(strtab + symtab[i].st_name)) + 1;

				pHandle->symtab[j].addr =
					(void *)((uint8_t*)pHandle->mem_ptr + symtab[i].st_value - pHandle->vstart_addr);
				pHandle->symtab[j].name = malloc(length);
				if(pHandle->symtab[j].name==NULL){
					DL_LOG_E("Module: allocate space failed.");
					err=DL_MALLOC_FAIL;
					goto fail3;
				}
				memcpy((void *)pHandle->symtab[j].name,
						  strtab + symtab[i].st_name,
						  length);
				((char*)pHandle->symtab[j].name)[length-1]='\0';
				j ++;
			}
		}
	}
	else{
		pHandle->symtab=NULL;
		pHandle->nsym=0;
	}
	return err;
fail3:	
	for(size_t i = 0;i < pHandle->nsym;i++){
		free((void*)pHandle->symtab[i].name);
	}
fail2:
	free(pHandle->symtab);
fail1:
	free(pHandle->mem_ptr);
fail0:
	return err;
}

//���ؿ��ļ��������
//pHandle�����
//file_name���ļ���
//����ֵ��DL_Err_Type ������
DL_Err_Type dl_load_lib(DL_Handler* pHandle,const char* file_name){
	DL_Err_Type err=DL_NO_ERR;
	FIL* pfile;
	uint8_t* file_buf;
	uint32_t br;
	pfile=malloc(sizeof(FIL));
	if(pfile==NULL){
		err=DL_MALLOC_FAIL;
		goto fail0;
	}
	
	if(f_open(pfile,file_name,FA_READ)!=FR_OK){
		err=DL_FILE_OPEN_ERR;
		goto fail0;
	}

	file_buf=malloc(f_size(pfile));
	if(file_buf==NULL){
		err=DL_MALLOC_FAIL;
		goto fail1;
	}

	if(f_read(pfile,file_buf,f_size(pfile),&br)!=FR_OK){
		err=DL_FILE_OPEN_ERR;
		goto fail2;
	}
	
	if(memcmp(elf_header(file_buf)->e_ident,ELFMAG,SELFMAG)!=0){
		err=DL_FILE_INVALID;
		goto fail2;
	}
	#if (defined(__arm__) || defined(__i386__) || (__riscv_xlen == 32))
	if(elf_header(file_buf)->e_ident[EI_CLASS]!=ELFCLASS32)
	#elif (defined(__aarch64__) || defined(__x86_64__) || (__riscv_xlen == 64))
	if(elf_header(file_buf)->e_ident[EI_CLASS]!=ELFCLASS64)
	#endif
	{
		err=DL_PLATFORM_ERR;
		goto fail2;
	}
	
	//�˴��Ǹ��ݱ��������ԣ�ѡ�����EXEC
	if(elf_header(file_buf)->e_type==ET_DYN||elf_header(file_buf)->e_type==ET_EXEC){
		err=dl_load_shared_object(pHandle,(void*)file_buf);
		if(err!=DL_NO_ERR){
			goto fail2;
		}
	}
	else{
		err=DL_ELF_NOT_SUPPRORT;
		goto fail2;
	}
	
	free(file_buf);
	f_close(pfile);
	free(pfile);
	
	#if defined(DL_CACHE_USE)&& DL_CACHE_USE==1
	extern void dl_cache_process(void* addr,size_t size);
	dl_cache_process(pHandle->mem_ptr,pHandle->mem_size);
	#endif
	
	return err;
fail2:
	free(file_buf);
fail1:	
	f_close(pfile);
fail0:
	free(pfile);
	return err;
}

//��ȡ���еĺ���ָ��
//pHandle�����
//sys_name��������
//����ֵ��void* ����ָ�루����NULLʱ����ʾδ�ҵ��ú�����
void* dl_get_func(DL_Handler* pHandle,const char* sys_name){
	for(size_t i=0;i<pHandle->nsym;i++){
		if(strcmp(sys_name,pHandle->symtab[i].name)==0){
			return pHandle->symtab[i].addr;
		}
	}
	return NULL;
}

//��ȡ���еĺ���ָ��
//pHandle�����
//����ֵ��(int(*)(int, char *[])) ����ָ�루����NULLʱ����ʾû����ں�����
int(*dl_get_entry(DL_Handler* pHandle))(int argc, char *argv[]){
	return (int(*)(int, char *[]))pHandle->entry_addr;
}

//�ͷż��ؿ���ڴ�
//pHandle�����
void dl_destroy_lib(DL_Handler* pHandle){
	for(size_t i=0;i<pHandle->nsym;i++){
		free((void*)pHandle->symtab[i].name);
	}
	free(pHandle->symtab);
	free(pHandle->mem_ptr);
}
