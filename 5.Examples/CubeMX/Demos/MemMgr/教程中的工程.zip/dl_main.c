

static int test_value=5;

__attribute__((aligned(1024)))int test_align[256];
__attribute__((visibility("default"))) int add(int a,int b){
	return a+b;
}
int dl_main(int argc, char *argv[]){
	test_value+=add(argc,1);
	test_align[0]=test_value;
	return test_value;
}
