#ifndef DL_EXTERN_LIB_H__
#define DL_EXTERN_LIB_H__

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdint.h>

#define DL_VECTOR_BASE_ADDR		0x3800C000
#define DL_VECTOR_SIZE			(16*1024)
#define DL_VECTOR(index)		(*(volatile void**)(DL_VECTOR_BASE_ADDR+sizeof(void*)*(index)))

//ʹ��DLL_EXPORT��������
#define DLL_EXPORT		__attribute__((visibility("default")))
#define DLL_HIDDEN		__attribute__((visibility("hidden")))

#if defined(__clang__)
#pragma clang diagnostic ignored "-Winvalid-source-encoding"
#endif

#endif
