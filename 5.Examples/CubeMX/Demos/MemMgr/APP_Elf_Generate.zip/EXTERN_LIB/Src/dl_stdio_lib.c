#include "dl_extern_lib.h"
#include <stdio.h>
#include <stdarg.h>

#define DL_STDIO_LIB_BASE		(0)

#define STDIN		((FILE *)DL_VECTOR(0+DL_STDIO_LIB_BASE))
#define STDOUT		((FILE *)DL_VECTOR(1+DL_STDIO_LIB_BASE))
#define STDERR		((FILE *)DL_VECTOR(2+DL_STDIO_LIB_BASE))
#define VFPRINTF	DL_VECTOR(3+DL_STDIO_LIB_BASE)
#define VFSCANF		DL_VECTOR(4+DL_STDIO_LIB_BASE)
#define REMOVE		DL_VECTOR(5+DL_STDIO_LIB_BASE)
#define RENAME		DL_VECTOR(6+DL_STDIO_LIB_BASE)
#define FCLOSE		DL_VECTOR(7+DL_STDIO_LIB_BASE)
#define FFLUSH		DL_VECTOR(8+DL_STDIO_LIB_BASE)
#define FOPEN		DL_VECTOR(9+DL_STDIO_LIB_BASE)
#define FREOPEN		DL_VECTOR(10+DL_STDIO_LIB_BASE)
#define FREAD		DL_VECTOR(11+DL_STDIO_LIB_BASE)
#define FWRITE		DL_VECTOR(12+DL_STDIO_LIB_BASE)
#define FSEEK		DL_VECTOR(13+DL_STDIO_LIB_BASE)
#define FTELL		DL_VECTOR(14+DL_STDIO_LIB_BASE)

__asm(".global __use_no_semihosting\n\t");

void _sys_exit(int code){
	
}

void _ttywrch(int ch){
	
}

int vfprintf(FILE * __restrict stream,const char * __restrict fmt, va_list arg){
	int(*use_vfprintf)(FILE *,const char *,va_list)=VFPRINTF;
	return use_vfprintf(stream,fmt,arg);
}

int vfscanf(FILE * __restrict stream, const char * __restrict fmt, va_list arg){
	int(*use_vfscanf)(FILE *, const char *, va_list)=VFSCANF;
	return use_vfscanf(stream,fmt,arg);
}

int vprintf(const char * __restrict fmt, va_list arg){
	return vfprintf(STDOUT,fmt,arg);
}

int printf(const char * __restrict fmt, ...){
	va_list arg;
	int ret;
	va_start(arg,fmt);
	ret=vprintf(fmt,arg);
	va_end(arg);
	return ret;
}

int vscanf(const char * __restrict fmt, va_list arg){
	return vfscanf(STDIN,fmt,arg);
}

int scanf(const char * __restrict fmt,...){
	va_list arg;
	int ret;
	va_start(arg,fmt);
	ret=vscanf(fmt,arg);
	va_end(arg);
	return ret;
}

int fprintf(FILE * __restrict stream,const char * __restrict fmt, ...){
	va_list arg;
	int ret;
	va_start(arg,fmt);
	ret=vfprintf(stream,fmt,arg);
	va_end(arg);
	return ret;
}

int remove(const char * filename){
	int(*use_remove)(const char*)=REMOVE;
	return use_remove(filename);
}

int rename(const char * old_name, const char * new_name){
	int(*use_rename)(const char *,const char *)=RENAME;
	return use_rename(old_name,new_name);
}

int fclose(FILE * pfile){
	int(*use_fclose)(FILE *)=FCLOSE;
	return use_fclose(pfile);
}

int fflush(FILE * pfile){
	int(*use_fflush)(FILE *)=FFLUSH;
	return use_fflush(pfile);
}

FILE *fopen(const char * __restrict file_name,const char * __restrict mode){
	FILE *(*use_fopen)(const char * __restrict file_name,const char * __restrict mode)=FOPEN;
	return use_fopen(file_name,mode);
}

FILE *freopen(const char * __restrict filename,const char * __restrict mode,FILE * __restrict stream){
	FILE *(*use_freopen)(const char * __restrict filename,const char * __restrict mode,FILE * __restrict stream)=FREOPEN;
	return use_freopen(filename,mode,stream);
}

size_t fread(void * __restrict ptr,size_t size, size_t nmemb, FILE * __restrict stream){
	size_t (*use_fread)(void * __restrict ptr,size_t size, size_t nmemb, FILE * __restrict stream)=FREAD;
	return use_fread(ptr,size,nmemb,stream);
}

size_t fwrite(const void * __restrict ptr,size_t size, size_t nmemb, FILE * __restrict stream){
	size_t (*use_fwrite)(const void * __restrict ptr,size_t size, size_t nmemb, FILE * __restrict stream)=FWRITE;
	return use_fwrite(ptr,size,nmemb,stream);
}

int fseek(FILE * stream, long int offset, int whence){
	int (*use_fseek)(FILE * stream, long int offset, int whence)=FSEEK;
	return use_fseek(stream,offset,whence);
}

long int ftell(FILE * stream){
	int (*use_ftell)(FILE * stream)=FTELL;
	return use_ftell(stream);
}


