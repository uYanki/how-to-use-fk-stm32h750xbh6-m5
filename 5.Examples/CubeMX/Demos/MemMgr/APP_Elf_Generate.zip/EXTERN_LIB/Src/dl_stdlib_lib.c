#include "dl_extern_lib.h"
#include <stdlib.h>

#define DL_STDLIB_LIB_BASE	 (15)

#define CALLOC		DL_VECTOR(0+DL_STDLIB_LIB_BASE)
#define FREE		DL_VECTOR(1+DL_STDLIB_LIB_BASE)
#define MALLOC		DL_VECTOR(2+DL_STDLIB_LIB_BASE)
#define REALLOC		DL_VECTOR(3+DL_STDLIB_LIB_BASE)
#define ALIGEND_ALLOC	DL_VECTOR(4+DL_STDLIB_LIB_BASE)

__asm(".global __use_no_heap_region\n\t");

void *calloc(size_t nmemb, size_t size){
	void* (*use_calloc)(size_t,size_t)=CALLOC;
	return use_calloc(nmemb,size);
}

void free(void * ptr){
	void(*use_free)(void*)=FREE;
	use_free(ptr);
}

void *malloc(size_t size){
	void*(*use_malloc)(size_t)=MALLOC;
	return use_malloc(size);
}

void *realloc(void * ptr, size_t size){
	void*(*use_realloc)(void*,size_t)=REALLOC;
	return use_realloc(ptr,size);
}

void *aligned_alloc(size_t align_byte,size_t size){
	void*(*use_aligned_alloc)(void*,size_t)=ALIGEND_ALLOC;
	return use_aligned_alloc(aligned_alloc,size);
}
