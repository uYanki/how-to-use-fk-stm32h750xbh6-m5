#include "dl_extern_lib.h"
#include <string.h>

//
void Malloc_test(void){
	static const uint32_t m_size=1024*1024;
	void* ptr;
	printf("malloc test:try malloc %d byte.\r\n",m_size);
	ptr=malloc(m_size);
	if(ptr==NULL)
		printf("malloc fail.\r\n");
	else
		printf("malloc success.\r\n");
	printf("free memory.\r\n");
	free(ptr);
}


DLL_EXPORT int test_func(int a){
	Malloc_test();
	return abs(a);
}

int dl_main(int argc, char *argv[]){
	printf("main test:hello world!\r\n");
	printf("command:\r\n");
	for(size_t i=0;i<argc;i++){
		printf("%s\r\n",argv[i]);
	}
	return 0;
}




