#include "shell.h"

#ifndef SHELL_NO_UTILS

// Modbus

int mbcfg(int argc, char* argv[])
{
    if (argc < 2)
    {
        shell_printf("Usage: %s <address> (in hex)\n", argv[0]);
        return -1;
    }

    uint32_t addr = _atoh(argv[1]);
    uint32_t data;

    data = REG32(addr);

    shell_printf("0x%x: 0x%x\n", addr, data);
    return 0;
}

int mbscan(int argc, char* argv[])
{
    if (argc < 2)
    {
        shell_printf("Usage: %s <address> (in hex)\n", argv[0]);
        return -1;
    }

    uint32_t addr = _atoh(argv[1]);
    uint32_t data;

    data = REG32(addr);

    shell_printf("0x%x: 0x%x\n", addr, data);
    return 0;
}

int mbset(int argc, char* argv[])
{
    if (argc < 2)
    {
        shell_printf("Usage: %s <address> (in hex)\n", argv[0]);
        return -1;
    }

    uint32_t addr = _atoh(argv[1]);
    uint32_t data;

    data = REG32(addr);

    shell_printf("0x%x: 0x%x\n", addr, data);
    return 0;
}

int mbset(int argc, char* argv[])
{
    if (argc < 2)
    {
        shell_printf("Usage: %s <address> (in hex)\n", argv[0]);
        return -1;
    }

    uint32_t addr = _atoh(argv[1]);
    uint32_t data;

    data = REG32(addr);

    shell_printf("0x%x: 0x%x\n", addr, data);
    return 0;
}

#endif