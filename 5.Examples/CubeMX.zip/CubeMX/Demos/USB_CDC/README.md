## CubeMx

![1](.assest/README/1.png)

![2](.assest/README/2.png)

## keil

#### printf

![3](.assest/README/3.png)