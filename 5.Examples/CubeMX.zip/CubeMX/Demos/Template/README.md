## CubeMX

### Clock

![1](.assest/README/1.png)

![2](.assest/README/2.png)

### SWD

![3](.assest/README/3.png)