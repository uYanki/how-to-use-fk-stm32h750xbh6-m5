/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2023 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usart.h"
#include "gpio.h"
#include "fmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "bsp.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void        SystemClock_Config(void);
static void MPU_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

#define SDRAM_Size      16 * 1024 * 1024  // 16M Bytes, W9812G6
// #define SDRAM_Size   32 * 1024 * 1024  // 32M Bytes, W9825G6

#define SDRAM_BANK_ADDR SDRAM_ADDR_BASE

ErrorStatus SDRAM_8Bit_Test(void)
{
    uint32_t i;
    uint8_t  Data;

    uint32_t ExecutionTime;
    uint32_t ExecutionTimeEnd;
    float    ExecutionSpeed;

    printf("%s\n", __func__);

    //-----------------------------------------
    // write

    ExecutionTime = HAL_GetTick();

    for (i = 0; i < SDRAM_Size; i++)
    {
        SDRAM_Byte(i) = (uint8_t)i;
    }

    ExecutionTimeEnd = HAL_GetTick();
    ExecutionSpeed   = (float)SDRAM_Size / 1024 / 1024 / (ExecutionTimeEnd - ExecutionTime) * 1000;  // unit = MB/S
    printf("- wirte %d MB, time = %d ms, speed = %.2f MB/s\n", SDRAM_Size / 1024 / 1024, ExecutionTime, ExecutionSpeed);

    //-----------------------------------------
    // read

    ExecutionTime = HAL_GetTick();

    for (i = 0; i < SDRAM_Size; i++)
    {
        Data = SDRAM_Byte(i);
    }

    ExecutionTimeEnd = HAL_GetTick();
    ExecutionSpeed   = (float)SDRAM_Size / 1024 / 1024 / (ExecutionTimeEnd - ExecutionTime) * 1000;  // unit = MB/S
    printf("- read %d MB, time = %d ms, speed = %.2f MB/s\n", SDRAM_Size / 1024 / 1024, ExecutionTime, ExecutionSpeed);

    //-----------------------------------------
    // check

    for (i = 0; i < SDRAM_Size; i++)
    {
        Data = SDRAM_Byte(i);

        if (Data != (uint8_t)i)
        {
            printf("- check fail, %d != %d\n", Data, i);

            return ERROR;
        }
    }

    printf("- check ok\n");

    return SUCCESS;
}

ErrorStatus SDRAM_16Bit_Test(void)
{
    uint32_t i;
    uint16_t Data;

    uint32_t ExecutionTime;
    uint32_t ExecutionTimeEnd;
    float    ExecutionSpeed;

    printf("%s\n", __func__);

    //-----------------------------------------
    // write

    ExecutionTime = HAL_GetTick();

    for (i = 0; i < SDRAM_Size / 2; i++)
    {
        SDRAM_Word(i) = (uint16_t)i;
    }

    ExecutionTimeEnd = HAL_GetTick();
    ExecutionSpeed   = (float)SDRAM_Size / 1024 / 1024 / (ExecutionTimeEnd - ExecutionTime) * 1000;  // unit = MB/S

    printf("- wirte %d MB, time = %d ms, speed = %.2f MB/s\n", SDRAM_Size / 1024 / 1024, ExecutionTime, ExecutionSpeed);

    //-----------------------------------------
    // read

    ExecutionTime = HAL_GetTick();

    for (i = 0; i < SDRAM_Size / 2; i++)
    {
        Data = SDRAM_Word(i);
    }

    ExecutionTimeEnd = HAL_GetTick();
    ExecutionSpeed   = (float)SDRAM_Size / 1024 / 1024 / (ExecutionTimeEnd - ExecutionTime) * 1000;  // unit = MB/S

    printf("- read %d MB, time = %d ms, speed = %.2f MB/s\n", SDRAM_Size / 1024 / 1024, ExecutionTime, ExecutionSpeed);

    //-----------------------------------------
    // check

    for (i = 0; i < SDRAM_Size / 2; i++)
    {
        Data = SDRAM_Word(i);

        if (Data != (uint16_t)i)
        {
            printf("- check fail, %d != %d\n", Data, i);
            return ERROR;
        }
    }

    printf("- check ok\n");

    return SUCCESS;
}

ErrorStatus SDRAM_32Bit_Test(void)
{
    uint32_t i;
    uint32_t Data;

    uint32_t ExecutionTime;
    uint32_t ExecutionTimeEnd;
    float    ExecutionSpeed;

    printf("%s\n", __func__);

    //-----------------------------------------
    // write

    ExecutionTime = HAL_GetTick();

    for (i = 0; i < SDRAM_Size / 4; i++)
    {
        SDRAM_DWord(i) = (uint32_t)i;
    }

    ExecutionTimeEnd = HAL_GetTick();

    ExecutionSpeed = (float)SDRAM_Size / 1024 / 1024 / (ExecutionTimeEnd - ExecutionTime) * 1000;  // unit = MB/S

    printf("- wirte %d MB, time = %d ms, speed = %.2f MB/s\n", SDRAM_Size / 1024 / 1024, ExecutionTime, ExecutionSpeed);

    //-----------------------------------------
    // read

    ExecutionTime = HAL_GetTick();

    for (i = 0; i < SDRAM_Size / 4; i++)
    {
        Data = SDRAM_DWord(i);
    }

    ExecutionTimeEnd = HAL_GetTick();

    ExecutionSpeed = (float)SDRAM_Size / 1024 / 1024 / (ExecutionTimeEnd - ExecutionTime) * 1000;  // unit = MB/S

    printf("- read %d MB, time = %d ms, speed = %.2f MB/s\n", SDRAM_Size / 1024 / 1024, ExecutionTime, ExecutionSpeed);

    //-----------------------------------------
    // check

    for (i = 0; i < SDRAM_Size / 4; i++)
    {
        Data = SDRAM_DWord(i);

        if (Data != (uint32_t)i)
        {
            printf("- check fail, %d != %d\n", Data, i);
            return ERROR;
        }
    }

    printf("- check ok\n");

    return SUCCESS;
}

uint8_t SDRAM_Test(void)
{
	uint32_t i = 0;			// ��������
	uint16_t ReadData = 0; 	// ��ȡ��������
	uint8_t  ReadData_8b;

	uint32_t ExecutionTime_Begin;		// ��ʼʱ��
	uint32_t ExecutionTime_End;		// ����ʱ��
	uint32_t ExecutionTime;				// ִ��ʱ��	
	float    ExecutionSpeed;			// ִ���ٶ�
	
	printf("\r\n*****************************************************************************************************\r\n");		
	printf("\r\n�����ٶȲ���>>>\r\n");

// д�� >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

	ExecutionTime_Begin 	= HAL_GetTick();	// ��ȡ systick ��ǰʱ�䣬��λms
	
	for (i = 0; i < SDRAM_Size/2; i++)
	{
 		*(__IO uint16_t*) (SDRAM_BANK_ADDR + 2*i) = (uint16_t)i;		// д������
	}
	ExecutionTime_End		= HAL_GetTick();											// ��ȡ systick ��ǰʱ�䣬��λms
	ExecutionTime  = ExecutionTime_End - ExecutionTime_Begin; 				// �������ʱ�䣬��λms
	ExecutionSpeed = (float)SDRAM_Size /1024/1024 /ExecutionTime*1000 ; 	// �����ٶȣ���λ MB/S	
	
	printf("\r\n��16λ���ݿ���д�����ݣ���С��%d MB����ʱ: %d ms, д���ٶȣ�%.2f MB/s\r\n",SDRAM_Size/1024/1024,ExecutionTime,ExecutionSpeed);

// ��ȡ	>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 

	ExecutionTime_Begin 	= HAL_GetTick();	// ��ȡ systick ��ǰʱ�䣬��λms
	
	for(i = 0; i < SDRAM_Size/2;i++ )
	{
		ReadData = *(__IO uint16_t*)(SDRAM_BANK_ADDR + 2 * i );  // ��SDRAM��������	
	}
	ExecutionTime_End		= HAL_GetTick();											// ��ȡ systick ��ǰʱ�䣬��λms
	ExecutionTime  = ExecutionTime_End - ExecutionTime_Begin; 				// �������ʱ�䣬��λms
	ExecutionSpeed = (float)SDRAM_Size /1024/1024 /ExecutionTime*1000 ; 	// �����ٶȣ���λ MB/S	
	
	printf("\r\n��ȡ������ϣ���С��%d MB����ʱ: %d ms, ��ȡ�ٶȣ�%.2f MB/s\r\n",SDRAM_Size/1024/1024,ExecutionTime,ExecutionSpeed);
	
// ����У�� >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>   
		
	printf("\r\n*****************************************************************************************************\r\n");		
	printf("\r\n��������У��>>>\r\n");
	
	for(i = 0; i < SDRAM_Size/2;i++ )
	{
		ReadData = *(__IO uint16_t*)(SDRAM_BANK_ADDR + 2 * i );  // ��SDRAM��������	
		if( ReadData != (uint16_t)i )      //������ݣ�������ȣ���������,���ؼ��ʧ�ܽ����
		{
			printf("\r\nSDRAM����ʧ�ܣ���\r\n");
			return ERROR;	 // ����ʧ�ܱ�־
		}
	}
	
	printf("\r\n16λ���ݿ��ȶ�дͨ������8λ���ݿ���д������\r\n");
	for (i = 0; i < 255; i++)
	{
 		*(__IO uint8_t*) (SDRAM_BANK_ADDR + i) =  (uint8_t)i;
	}	
	printf("д����ϣ���ȡ���ݲ��Ƚ�...\r\n");
	for (i = 0; i < 255; i++)
	{
		ReadData_8b = *(__IO uint8_t*) (SDRAM_BANK_ADDR + i);
		if( ReadData_8b != (uint8_t)i )      //������ݣ�������ȣ���������,���ؼ��ʧ�ܽ����
		{
			printf("8λ���ݿ��ȶ�д����ʧ�ܣ���\r\n");
			printf("����NBL0��NBL1������\r\n");	
			return ERROR;	 // ����ʧ�ܱ�־
		}
	}		
	printf("8λ���ݿ��ȶ�дͨ��\r\n");
	printf("SDRAM��д����ͨ����ϵͳ����\r\n");
	return SUCCESS;	 // ���سɹ���־
}



/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{
    /* USER CODE BEGIN 1 */

    /* USER CODE END 1 */

    /* MPU Configuration--------------------------------------------------------*/
    MPU_Config();
    /* Enable the CPU Cache */

    /* Enable I-Cache---------------------------------------------------------*/
    SCB_EnableICache();

    /* Enable D-Cache---------------------------------------------------------*/
    SCB_EnableDCache();

    /* MCU Configuration--------------------------------------------------------*/

    /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
    HAL_Init();

    /* USER CODE BEGIN Init */

    /* USER CODE END Init */

    /* Configure the system clock */
    SystemClock_Config();

    /* USER CODE BEGIN SysInit */

    /* USER CODE END SysInit */

    /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_USART1_UART_Init();
    MX_FMC_Init();
    /* USER CODE BEGIN 2 */
    SDRAM_Initialization_Sequence(&hsdram1);
		SDRAM_Test();
    SDRAM_8Bit_Test();
    SDRAM_16Bit_Test();
    SDRAM_32Bit_Test();
    /* USER CODE END 2 */

    /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1)
    {
        /* USER CODE END WHILE */

        /* USER CODE BEGIN 3 */
    }
    /* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    /** Supply configuration update enable
     */
    HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

    /** Configure the main internal regulator output voltage
     */
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    while (!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

    __HAL_RCC_SYSCFG_CLK_ENABLE();
    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);

    while (!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

    /** Initializes the RCC Oscillators according to the specified parameters
     * in the RCC_OscInitTypeDef structure.
     */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
    RCC_OscInitStruct.HSEState       = RCC_HSE_ON;
    RCC_OscInitStruct.PLL.PLLState   = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource  = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLM       = 5;
    RCC_OscInitStruct.PLL.PLLN       = 192;
    RCC_OscInitStruct.PLL.PLLP       = 2;
    RCC_OscInitStruct.PLL.PLLQ       = 2;
    RCC_OscInitStruct.PLL.PLLR       = 2;
    RCC_OscInitStruct.PLL.PLLRGE     = RCC_PLL1VCIRANGE_2;
    RCC_OscInitStruct.PLL.PLLVCOSEL  = RCC_PLL1VCOWIDE;
    RCC_OscInitStruct.PLL.PLLFRACN   = 0;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    /** Initializes the CPU, AHB and APB buses clocks
     */
    RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2 | RCC_CLOCKTYPE_D3PCLK1 | RCC_CLOCKTYPE_D1PCLK1;
    RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.SYSCLKDivider  = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.AHBCLKDivider  = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
    RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
    {
        Error_Handler();
    }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* MPU Configuration */

void MPU_Config(void)
{
		MPU_Region_InitTypeDef MPU_InitStruct;

	HAL_MPU_Disable();		// �Ƚ�ֹMPU

	MPU_InitStruct.Enable           = MPU_REGION_ENABLE;
	MPU_InitStruct.BaseAddress      = SDRAM_BANK_ADDR;
	MPU_InitStruct.Size             = MPU_REGION_SIZE_32MB;
	MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
	MPU_InitStruct.IsBufferable     = MPU_ACCESS_NOT_BUFFERABLE;
	MPU_InitStruct.IsCacheable      = MPU_ACCESS_CACHEABLE;
	MPU_InitStruct.IsShareable      = MPU_ACCESS_NOT_SHAREABLE;
	MPU_InitStruct.Number           = MPU_REGION_NUMBER2;
	MPU_InitStruct.TypeExtField     = MPU_TEX_LEVEL0;
	MPU_InitStruct.SubRegionDisable = 0x00;
	MPU_InitStruct.DisableExec      = MPU_INSTRUCTION_ACCESS_ENABLE;

	HAL_MPU_ConfigRegion(&MPU_InitStruct);

	HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);	// ʹ��MPU
	return;
   // MPU_Region_InitTypeDef MPU_InitStruct = {0};

    /* Disables the MPU */
    HAL_MPU_Disable();

    /** Initializes and configures the Region and the memory to be protected
     */
    MPU_InitStruct.Enable           = MPU_REGION_ENABLE;
    MPU_InitStruct.Number           = MPU_REGION_NUMBER2;
    MPU_InitStruct.BaseAddress      = SDRAM_BANK_ADDR;
    MPU_InitStruct.Size             = MPU_REGION_SIZE_32MB;
    MPU_InitStruct.SubRegionDisable = 0x00;
    MPU_InitStruct.TypeExtField     = MPU_TEX_LEVEL0;
    MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
    MPU_InitStruct.DisableExec      = MPU_INSTRUCTION_ACCESS_ENABLE;
    MPU_InitStruct.IsShareable      = MPU_ACCESS_NOT_SHAREABLE;
    MPU_InitStruct.IsCacheable      = MPU_ACCESS_CACHEABLE;
    MPU_InitStruct.IsBufferable     = MPU_ACCESS_NOT_BUFFERABLE;

    HAL_MPU_ConfigRegion(&MPU_InitStruct);
    /* Enables the MPU */
    HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
}

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
    /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */
    __disable_irq();
    while (1)
    {
    }
    /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t* file, uint32_t line)
{
    /* USER CODE BEGIN 6 */
    /* User can add his own implementation to report the file name and line number,
       ex: printf("Wrong parameters value: file %s on line %d\n", file, line) */
    /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
