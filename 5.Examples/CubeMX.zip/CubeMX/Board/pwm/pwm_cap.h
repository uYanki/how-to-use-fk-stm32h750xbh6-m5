#ifndef __PWM_GEN_H__
#define __PWM_GEN_H__

#include "stm32h7xx_hal.h"

#endif
